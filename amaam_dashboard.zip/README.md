# AMAAM Dashboard

This is the React + Tailwind dashboard UI for logged-in users.